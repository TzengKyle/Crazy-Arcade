#include "End.h"
#include "ui_End.h"

#include <QObject>



End::End(int a, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::End)
{
    ui->setupUi(this);
    this->scene=new Scene;

    if(a==1){
        QImage image(QString(":/img/img/two_wins.png"));
        ui->label->setPixmap(QPixmap::fromImage(image));
        ui->label->resize(image.width(),image.height());

    }else{
        QImage image(QString(":/img/img/one_wins.png"));
        ui->label->setPixmap(QPixmap::fromImage(image));
        ui->label->resize(image.width(),image.height());
    }

    //window的標題和圖示
    setWindowTitle(tr("Result"));
    setWindowIcon(QPixmap(":img/img/bomb.png"));
}

End::~End()
{
    delete ui;
}
