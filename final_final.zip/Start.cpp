#include "Start.h"
#include "ui_Start.h"

#include "Game.h"


Start::Start(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Start)
{
    ui->setupUi(this);
    //window的標題和圖示
    setWindowTitle(tr("Bomberman"));
    setWindowIcon(QPixmap(":img/img/bomb.png"));
    this->s=new Scene;
    QMovie *movie = new QMovie(":/gif/gif/Yo.gif");
    ui->label->setMovie(movie);
    movie->start();
}

Start::~Start()
{
    delete ui;
}

void Start::on_NewAsButton_clicked()
{
    Game *game = new Game(0);
    game->show();
    this->hide();
    //delete this;
}

void Start::readFile(const QString &fileName)
{
    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        qDebug() << "Cannot open file for reading:" << qPrintable(file.errorString());
        return;
    }

    QTextStream in(&file);
    while (!in.atEnd())
    {
        QStringList fileLine = in.readLine().split(" ");
        qDebug() << fileLine;
        qDebug() << fileLine[0];
    }
    file.close();
}


void Start::on_RecordAsButton_clicked()
{
    Game *game = new Game(1);;
    game->show();
    this->hide();

}

