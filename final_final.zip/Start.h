#ifndef START_H
#define START_H

#include <QMainWindow>
#include <QSplashScreen>
#include <QMovie>
#include <QLabel>
#include <QMediaPlayer>


#include "Game.h"
#include "Scene.h"
namespace Ui {
class Start;
}

class Start : public QMainWindow
{
    Q_OBJECT

public:
    Start(QWidget *parent = nullptr);
    ~Start();

private slots:
    void on_NewAsButton_clicked();

    void readFile(const QString &fileName);
    void on_RecordAsButton_clicked();

private:
    Ui::Start *ui;
    Scene *s;

    QMovie *move;
};

#endif // START_H
