#include "Undestroyableblock.h"

UnDestroyableBlock::UnDestroyableBlock(QObject *parent)
    : QObject{parent}
{

}
