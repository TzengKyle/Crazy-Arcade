#include "Scene.h"
#include <QGraphicsScene> //temp
#include <QHBoxLayout>
#include <QLabel>
#include <QPixmap>
#include <QtGui>

Scene::Scene(QGraphicsScene *parent)
    : QGraphicsScene{parent}
{

}
